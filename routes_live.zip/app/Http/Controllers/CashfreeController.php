<?php 

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Order;

class CashfreeController extends Controller
{
    public function pay($order_id)
    {
        $order = Order::findOrFail($order_id);

        $postData = [
            "appId" => env('CASHFREE_APP_ID'),
            "orderId" => $order->order_number,
            "orderAmount" => $order->total_amount,
            "orderCurrency" => "INR",
            "orderNote" => "Order Payment",
            "customerName" => auth()->user()->name,
            "customerPhone" => auth()->user()->phone,
            "customerEmail" => auth()->user()->email,
            "returnUrl" => route('cashfree.callback'),
        ];

        $signatureData = implode("", $postData);
        $postData["signature"] = hash_hmac('sha256', $signatureData, env('CASHFREE_SECRET_KEY'), false);

        return view('cashfree.pay', compact('postData'));
    }

    public function callback(Request $request)
    {
        $order = Order::where('order_number', $request->orderId)->first();

        if($request->txStatus == 'SUCCESS'){
            $order->payment_status = 'paid';
        } else {
            $order->payment_status = 'failed';
        }

        $order->save();

        return redirect()->route('home')->with('success', 'Payment status updated: '.$request->txStatus);
    }
}
